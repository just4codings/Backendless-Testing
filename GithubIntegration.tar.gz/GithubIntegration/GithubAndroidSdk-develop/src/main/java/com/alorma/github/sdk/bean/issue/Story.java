package com.alorma.github.sdk.bean.issue;

import java.util.List;

public class Story<K> {

  public K item;
  public List<IssueStoryDetail> details;
}
