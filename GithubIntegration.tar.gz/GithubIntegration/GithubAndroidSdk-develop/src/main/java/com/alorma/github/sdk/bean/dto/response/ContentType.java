package com.alorma.github.sdk.bean.dto.response;

/**
 * Created by Bernat on 20/07/2014.
 */
public enum ContentType {
  file,
  dir,
  symlink
}
