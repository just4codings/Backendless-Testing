package com.alorma.gitskarios.core.client;

/**
 * Created by Bernat on 13/07/2014.
 */
public enum RelType {

  next,
  last,
  first,
  prev

}
