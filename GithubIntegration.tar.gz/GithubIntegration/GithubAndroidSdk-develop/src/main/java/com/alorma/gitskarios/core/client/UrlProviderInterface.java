package com.alorma.gitskarios.core.client;

/**
 * Created by bernat.borras on 8/1/16.
 */
public interface UrlProviderInterface {
  String getUrl();
}
