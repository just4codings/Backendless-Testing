package com.alorma.github.sdk.bean.dto.request;

public class WebHookConfigRequest {
  public String url;
  public String content_type;
}
