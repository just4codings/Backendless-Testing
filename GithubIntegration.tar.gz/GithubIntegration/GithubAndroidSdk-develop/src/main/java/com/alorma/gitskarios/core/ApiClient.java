package com.alorma.gitskarios.core;

/**
 * Created by Bernat on 19/04/2015.
 */
public interface ApiClient {

  String getApiOauthUrlEndpoint();

  String getApiEndpoint();

  String getType();
}
