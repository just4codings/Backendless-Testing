package com.alorma.github.sdk.bean.dto.response;

/**
 * Created by Bernat on 13/07/2014.
 */
public enum UserType {
  User,
  Organization
}
