package com.alorma.github.sdk.exception;

/**
 * Created by Bernat on 08/07/2014.
 */
public class ApiException extends Exception {
}
