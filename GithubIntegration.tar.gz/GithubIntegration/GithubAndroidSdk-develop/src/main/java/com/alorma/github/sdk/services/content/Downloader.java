package com.alorma.github.sdk.services.content;

/**
 * Created by bernat.borras on 7/1/16.
 */
public interface Downloader {
  void download(String path);
}
