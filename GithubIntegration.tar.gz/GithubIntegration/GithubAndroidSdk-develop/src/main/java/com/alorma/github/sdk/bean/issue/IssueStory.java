package com.alorma.github.sdk.bean.issue;

import com.alorma.github.sdk.bean.dto.response.Issue;

public class IssueStory extends Story<Issue> {

  public IssueStory() {
  }
}
