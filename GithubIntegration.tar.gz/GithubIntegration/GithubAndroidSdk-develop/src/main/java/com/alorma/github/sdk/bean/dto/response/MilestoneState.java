package com.alorma.github.sdk.bean.dto.response;

/**
 * Created by Bernat on 22/08/2014.
 */
public enum MilestoneState {
  open,
  close
}
