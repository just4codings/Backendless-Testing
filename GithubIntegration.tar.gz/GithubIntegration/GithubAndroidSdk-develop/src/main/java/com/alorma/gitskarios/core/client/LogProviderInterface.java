package com.alorma.gitskarios.core.client;

/**
 * Created by bernat.borras on 9/1/16.
 */
public interface LogProviderInterface {
  void log(String message);
}
