package com.alorma.github.sdk.services.user;

public class UnauthorizedException extends Throwable {
}
