package com.alorma.github.sdk.services.user;

public class TwoFactorAuthException extends Throwable {
}
