package com.alorma.github.sdk.bean.dto.response;

public enum GitTreeType {
  tree,
  blob,
  commit
}
