package com.alorma.github.sdk.bean.issue;

import com.alorma.github.sdk.bean.dto.response.PullRequest;

public class PullRequestStory extends Story<PullRequest> {

  public PullRequestStory() {
  }
}
