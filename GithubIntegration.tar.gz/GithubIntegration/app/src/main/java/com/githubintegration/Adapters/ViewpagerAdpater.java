package com.githubintegration.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.githubintegration.Fragments.code;
import com.githubintegration.Fragments.commits;
import com.githubintegration.Fragments.issues;

/**
 * Created by nnadmin on 30/4/16.
 */
public class ViewpagerAdpater  extends FragmentStatePagerAdapter {
    int NumbOfTabs;

    public ViewpagerAdpater(FragmentManager supportFragmentManager, int numboftabs) {
        super(supportFragmentManager);
        NumbOfTabs=numboftabs;

    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                commits.newInstance();
                break;
            case 1:
                issues.newInstance();
                break;
            case 2:
                code.newInstance();
        }
        return null;
    }

    @Override
    public int getCount() {
        return NumbOfTabs;
    }
}
