package com.githubintegration;

import android.app.Activity;

/**
 * Created by nnadmin on 29/4/16.
 */
public class Commonclass {
    Activity activity;
    public Commonclass(Activity activi) {
        activity=activi;

    }

    public static boolean isEmptyString(String text) {
        return (text == null || text.trim().equals("null") || text.trim()
                .length() <= 0 || null ==text || text.equals(""));
    }


}
