package com.githubintegration;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alorma.github.sdk.bean.dto.response.Commit;
import com.alorma.github.sdk.bean.dto.response.Issue;
import com.alorma.github.sdk.bean.dto.response.Repo;
import com.alorma.github.sdk.bean.dto.response.User;
import com.alorma.github.sdk.bean.info.CommitInfo;
import com.alorma.github.sdk.bean.info.IssueInfo;
import com.alorma.github.sdk.bean.info.RepoInfo;
import com.alorma.github.sdk.exception.ApiException;
import com.alorma.github.sdk.services.commit.ListCommitsClient;
import com.alorma.github.sdk.services.issues.GetIssuesClient;
import com.alorma.github.sdk.services.repos.GithubReposClient;
import com.alorma.github.sdk.services.repos.UserReposClient;
import com.alorma.gitskarios.core.Pair;
import com.alorma.gitskarios.core.client.TokenProvider;
import com.githubintegration.Adapters.ReposAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.Bind;
import butterknife.ButterKnife;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class MainActivity extends AppCompatActivity {
    TokenProvider tokenProvider;
    String token;
    GithubReposClient client;

    List<Repo> repos = new ArrayList<>();
  /*  @Bind(R.id.toolbar_title)
    TextView toolbarTitle;*/
    @Bind(R.id.toolBar)
    Toolbar toolBar;
    @Bind(R.id.toollinear)
    LinearLayout toollinear;
    @Bind(R.id.Reclycer)
    RecyclerView Reclycer;
    User userdetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        assert getSupportActionBar() != null;
        setSupportActionBar(toolBar);
        toolBar.setTitleTextColor(ContextCompat.getColor(this, R.color.darkgray));
        Reclycer.setHasFixedSize(true);
        Reclycer.setLayoutManager(new LinearLayoutManager(this));



           GetReposdetails();


    }

    private void GetReposdetails() {
        userdetails= git_singleton.getInstance().getuserdetails();
        System.out.println("++Mainactivity"+ git_singleton.getInstance().getuserdetails().toString() );
        client = new UserReposClient(userdetails.login, "full_name");


        client.observable().observeOn(AndroidSchedulers.mainThread()).subscribeOn(Schedulers.newThread())
                .subscribe(new Action1<Pair<List<Repo>, Integer>>() {
                    @Override
                    public void call(Pair<List<Repo>, Integer> listIntegerPair) {
                        System.out.println("+++++" + listIntegerPair.hashCode());

                        repos = listIntegerPair.first;
                        if(repos!=null&&repos.size()>0) {
                            git_singleton.getInstance().setReposDetails(repos);
                            ReposAdapter adapter = new ReposAdapter(repos, MainActivity.this);
                            Reclycer.setAdapter(adapter);
                        }

                       // Getissues();
                    }
                });
    }

    private void Getissues() {

        RepoInfo repoInfo = new RepoInfo();
        repoInfo.owner = "just4codings";
        repoInfo.branch = "master";
        repoInfo.name = "Backendless-Testing";


        IssueInfo issueInfo = new IssueInfo();
        issueInfo.repoInfo = repoInfo;
        HashMap<String, String> bb = new HashMap<>();
        bb.put("all", "assigned");


        new GetIssuesClient(issueInfo, bb).observable().observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.newThread())
                .subscribe(new Action1<Pair<List<Issue>, Integer>>() {
                    @Override
                    public void call(Pair<List<Issue>, Integer> listIntegerPair) {
                        if (listIntegerPair != null) {
                            List<Issue> repos = listIntegerPair.first;
                            System.out.println("+Issue lenght+" + repos.size() + "values" + repos.get(0).toString());
                            Getcommits();
                        }

                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        if (throwable instanceof ApiException) {
                            System.out.println("APIEXcpetion+" + throwable.toString());
                        } else {
                            System.out.println("Issues+" + throwable.toString());
                        }

                        Getcommits();
                    }
                });


    }

    private void Getcommits() {


        RepoInfo one = new RepoInfo();
        one.owner = "just4codings";
        one.branch = "master";
        one.name = "Backendless-Testing";
        CommitInfo commitInfo = new CommitInfo();
        commitInfo.repoInfo = one;
        commitInfo.sha = "master";
        /*new GetCommitCommentsClient(commitInfo,2).observable().observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.newThread())
                .subscribe(new Action1<Pair<List<CommitComment>, Integer>>() {
                    @Override
                    public void call(Pair<List<CommitComment>, Integer> listIntegerPair) {
                        if(listIntegerPair!=null) {
                            List<CommitComment> repos = listIntegerPair.first;
                            Toast.makeText(MainActivity.this, "commits: " + repos.get(0).toString(), Toast.LENGTH_SHORT)
                                    .show();
                            System.out.println("+commits lenght+" + repos.size() + "values" + repos.get(0).toString());
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        if (throwable instanceof ApiException) {
                            System.out.println("APIEXcpetion+" + throwable.toString());
                        }else {
                            System.out.println("commits+" + throwable.toString());
                        }
                    }
                });*/

        new ListCommitsClient(commitInfo, 0).observable().observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.newThread()).subscribe(new Action1<Pair<List<Commit>, Integer>>() {
            @Override
            public void call(Pair<List<Commit>, Integer> listIntegerPair) {
                List<Commit> repos = listIntegerPair.first;
                Toast.makeText(MainActivity.this, "commits: " + repos.get(0).toString(), Toast.LENGTH_SHORT)
                        .show();
                System.out.println("+commits lenght+" + repos.size() + "values" + repos.get(0).toString());

                //Get_archive();
            }
        });


    }

   /* private void Get_archive() {
        RepoInfo one=new RepoInfo();
        one.owner="just4codings";
        one.branch="master";
        one.name="Backendless-Testing";
        new GetArchiveLinkService()

    }*/



   /* private void manageTwoFactor() {
        String user = userText.getText().toString();
        String password = passText.getText().toString();
        String otp = otpText.getText().toString();

        CreateAuthorization createAuth = new CreateAuthorization();
        createAuth.scopes = new String[] { "repo", "user" };
        createAuth.note = "TestAppGitskariosSdk " + System.currentTimeMillis();
        CreateAuthorizationClient client = new CreateAuthorizationClient(user, password, createAuth);

        if (!TextUtils.isEmpty(otp)) {
            client.setOtpCode(otp);
        }

        client.observable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribeOn(Schedulers.newThread())
                .subscribe(new Action1<GithubAuthorization>() {
                    @Override
                    public void call(GithubAuthorization githubAuthorization) {
                        Toast.makeText(MainActivity.this, "Authorization: " + githubAuthorization.toString(),
                                Toast.LENGTH_SHORT).show();

                        onToken(githubAuthorization.token);
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable throwable) {
                        if (throwable instanceof TwoFactorAuthException) {
                            otpText.setEnabled(true);

                            Toast.makeText(MainActivity.this, "provide otp code sent by sms", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }*/
}




