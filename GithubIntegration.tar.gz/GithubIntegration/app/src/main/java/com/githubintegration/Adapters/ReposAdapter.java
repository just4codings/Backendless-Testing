package com.githubintegration.Adapters;

import android.app.Activity;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.alorma.github.sdk.bean.dto.response.Repo;
import com.githubintegration.Commonclass;
import com.githubintegration.MainActivity;
import com.githubintegration.R;
import com.githubintegration.git_singleton;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.ocpsoft.pretty.time.PrettyTime;

import java.util.List;

/**
 * Created by nnadmin on 30/4/16.
 */
public class ReposAdapter extends RecyclerView
.Adapter<RecyclerView.ViewHolder>  {
    List<Repo> repo;
    Activity activity;
    Commonclass common;
    View itemLayout;

    LayoutInflater layoutInflater;
    protected ImageLoader imageLoader;
    DisplayImageOptions options;
    public ReposAdapter(List<Repo> repos, Activity Activi) {
        common=new Commonclass(Activi);
        repo=repos;
        activity=Activi;
        layoutInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        String mode=null;
        if(activity.getClass().getName().toString().contains("com.githubintegration.MainActivity")){
            itemLayout =  LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.repos_item, parent, false);
            mode="MainActivity";
        }

        return new ReposAdapter.MyViewHolder(itemLayout, viewType,mode,activity);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder hold, int position) {
        if (hold instanceof MyViewHolder) {
            MyViewHolder holder = (MyViewHolder) hold;
            if(!common.isEmptyString(repo.get(position).name)){
                holder.reponame.setText(repo.get(position).name);
            }else {
                holder.reponame.setVisibility(View.GONE);
            }

            if(!common.isEmptyString(repo.get(position).description)){
                holder.descript.setText(repo.get(position).description);
            }else {
                holder.reponame.setVisibility(View.GONE);
            }
            if(repo.get(position).updated_at!=null){
                PrettyTime prettyTime=new PrettyTime();
                System.out.println("prettyTime"+prettyTime.format(repo.get(position).updated_at));
                holder.updatedate.setText("updated "+prettyTime.format(repo.get(position).updated_at));
            }


           /* if(!common.isEmptyString(repo.get(position).updated_at)){
                holder.descript.setText(repo.get(position).description);
            }else {
                holder.reponame.setVisibility(View.GONE);
            }*/

        }


    }

    @Override
    public int getItemCount() {
        int size=0;
        if(activity.getClass().getName().toString().contains("com.githubintegration.MainActivity")){
            size=repo.size();
        }
        return size;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView reponame,descript,updatedate;

        public MyViewHolder(View itemLayout, int viewType, String p2, Activity p3) {
            super(itemLayout);
            if(p2.equals("MainActivity")){
                reponame= (TextView) itemLayout.findViewById(R.id.reponame);
                descript= (TextView) itemLayout.findViewById(R.id.Description);
                updatedate= (TextView) itemLayout.findViewById(R.id.updatedate);
            }
        }
    }
}
