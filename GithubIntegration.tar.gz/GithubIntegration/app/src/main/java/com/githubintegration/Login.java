package com.githubintegration;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.alorma.github.sdk.bean.dto.response.User;
import com.alorma.github.sdk.services.user.GetAuthUserClient;
import com.alorma.github.sdk.services.user.TwoFactorAuthException;
import com.alorma.github.sdk.services.user.UnauthorizedException;

import butterknife.Bind;
import butterknife.ButterKnife;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.schedulers.Schedulers;

public class Login extends AppCompatActivity implements View.OnClickListener {

    @Bind(R.id.etusername)
    EditText etusername;
    @Bind(R.id.pwd)
    EditText pwd;
    @Bind(R.id.btnguest)
    Button btnguest;
    public String Tag="LoginScreen";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        btnguest.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnguest:
                if(Commonclass.isEmptyString(etusername.getText().toString())){
                    etusername.setError(getResources().getString(R.string.ed_login_user));
                } else if(Commonclass.isEmptyString(pwd.getText().toString())){
                    etusername.setError(getResources().getString(R.string.ed_login_pass));
                }else {
                    new GetAuthUserClient(etusername.getText().toString(),pwd.getText().toString()).observable()
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribeOn(Schedulers.newThread())
                            .subscribe(new Action1<User>() {
                                @Override
                                public void call(User user) {
                                    Log.e(Tag, user.toString());
                                    git_singleton.getInstance().setUserdetails(user);
                                    startActivity(new Intent(Login.this, MainActivity.class));
                                    finish();

                                }
                            }, new Action1<Throwable>() {
                                @Override
                                public void call(Throwable throwable) {
                                    if (throwable instanceof UnauthorizedException) {
                                        Toast.makeText(Login.this, "incorrect credentials", Toast.LENGTH_SHORT).show();
                                    } else if (throwable instanceof TwoFactorAuthException) {
                                        // manageTwoFactor();
                                    } else {
                                        Log.e(Tag, throwable.getMessage());
                                    }
                                }
                            });
                }
                break;
        }
    }
}
